#!/bin/bash
set -e

echo "🚀 กำลังติดตั้ง NGINX + PHP..."
apt update
apt install -y nginx php php-fpm

echo "📁 สร้างโฟลเดอร์ /var/www/m3u8proxy"
mkdir -p /var/www/m3u8proxy
cp index.php /var/www/m3u8proxy/index.php
cp stream.php /var/www/m3u8proxy/stream.php
chown -R www-data:www-data /var/www/m3u8proxy

echo "📝 ตั้งค่า NGINX..."
cat > /etc/nginx/sites-available/m3u8proxy.conf <<EOF
server {
    listen 6969;
    server_name _;
    root /var/www/m3u8proxy;
    index index.php;
    location / {
        try_files $uri $uri/ =404;
    }
    location ~ \.php$ {
        include snippets/fastcgi-php.conf;
        fastcgi_pass unix:/run/php/php-fpm.sock;
    }
}
EOF

ln -sf /etc/nginx/sites-available/m3u8proxy.conf /etc/nginx/sites-enabled/m3u8proxy.conf

echo "🔁 รีโหลด NGINX..."
nginx -t && systemctl reload nginx

echo "✅ เสร็จแล้ว! เปิด http://<IPเซิร์ฟเวอร์>:6969 ใช้งานได้เลย"
