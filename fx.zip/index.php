<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $url = trim($_POST['url']);
    $referer = trim($_POST['referer']);
    if (filter_var($url, FILTER_VALIDATE_URL) && filter_var($referer, FILTER_VALIDATE_URL)) {
        $encodedUrl = urlencode($url);
        $encodedReferer = urlencode($referer);
        $proxyUrl = "/stream.php?url={$encodedUrl}&referer={$encodedReferer}";
        echo "<div style='margin-top:20px;'><strong>✅ ลิงก์ของคุณ:</strong> <a href='{$proxyUrl}' target='_blank'>{$proxyUrl}</a></div>";
    } else {
        echo "<div style='color:red;'>URL หรือ Referer ไม่ถูกต้อง</div>";
    }
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <title>แปลงลิงก์ M3U8 Proxy</title>
    <style>
        body { font-family: sans-serif; background: #0f1115; color: white; padding: 20px; }
        form { background: #1e1f26; padding: 20px; border-radius: 10px; max-width: 500px; margin: auto; }
        input[type=text] { width: 100%; padding: 10px; margin: 10px 0; border: none; border-radius: 5px; }
        button { padding: 10px 20px; background: #007BFF; color: white; border: none; border-radius: 5px; cursor: pointer; }
        button:hover { background: #0056b3; }
        a { color: #00ffff; word-break: break-all; }
    </style>
</head>
<body>
    <h2 style="text-align:center;">🔄 แปลงลิงก์ M3U8 + Referer</h2>
    <form method="POST">
        <label>ลิงก์ .m3u8:</label>
        <input type="text" name="url" placeholder="https://..." required>
        <label>ลิงก์ Referer:</label>
        <input type="text" name="referer" placeholder="https://..." required>
        <button type="submit">✅ แปลงลิงก์</button>
    </form>
</body>
</html>
