<?php
if (!isset($_GET['url']) || !isset($_GET['referer'])) {
    http_response_code(400);
    exit("Missing url or referer");
}

$url = $_GET['url'];
$referer = $_GET['referer'];

$options = [
    "http" => [
        "method" => "GET",
        "header" => "Referer: $referer\r\nUser-Agent: Mozilla/5.0"
    ]
];

$context = stream_context_create($options);
$content = @file_get_contents($url, false, $context);

if ($content === false) {
    http_response_code(502);
    exit("Failed to fetch content");
}

$ext = pathinfo(parse_url($url, PHP_URL_PATH), PATHINFO_EXTENSION);
header("Content-Type: application/vnd.apple.mpegurl");
if ($ext === "ts") {
    header("Content-Type: video/MP2T");
}

echo $content;
?>
